#%% Import packages and modules
import numpy as np
from LP_class import makeCell
from timeSeriesAnalysis import burstAnalysis
import standardWaveforms as wfmGen
from masterValidation import masterValidation
from scipy.optimize import curve_fit
import torch

def ac_sigmoid(x, a, b, c):
    y = a / (1 + np.exp(-((x-b)/c)))
    return (y)

def ac_powerFxn(x,a,b,I0):
    y = a*(x-I0)**b
    y[np.isnan(y)]= 0
    return y

def modelRun(params,mechsList, caseStr, mechsVarsOfInt = {}, caseVars = None, fullReturn = False,cvodeBool=0):

    LP = makeCell('LP')
    LP_validation =  masterValidation(LP, LP.h)
    LP_validation.voltageHocGen()
    LP_validation.timeHocGen()
    
    somaArea_mm2 = LP.somaArea_mm2
    axonArea_mm2 = LP.axonArea_mm2
    

    if type(params) == torch.Tensor:
        params = params.numpy()


    for idxMech,mechVal in enumerate(mechsList):
        if 'axon' in mechVal: 
            mechName = mechVal.split('_axon')[0]  
            if 'gbar' in mechName:
                scalarVal = axonArea_mm2
            else:
                scalarVal = 1  
            setattr(LP.axon(0.5),mechName,params[idxMech]/scalarVal)
        if 'soma' in mechVal:
            mechName = mechVal.split('_soma')[0] 
            if 'gbar' in mechName:
                scalarVal = somaArea_mm2
            else:
                scalarVal = 1                 
            setattr(LP.soma(0.5),mechName,params[idxMech]/scalarVal)
    
    if len(mechsVarsOfInt) == 0 :
        mechsClass = []
    else:
        import mechanismSelector as mechSelect
        somaPSection = LP.soma.psection()
        mechsClass = mechSelect.VarsRecorder(LP.soma(0.5),somaPSection['density_mechs'], LP.h)
        mechsOfInterest = mechsVarsOfInt['mechsOfInterest']
        varsOfInterest = mechsVarsOfInt['varsOfInterest']
        mechsClass.selectMechs(mechsOfInterest,varsOfInterest)
        mechsClass.hocVecGen()      

    clampSection = LP.somaSection
    
    def finitFxn():
        LP.soma(0.5).v = LP.soma(0.5).leak.e
        LP.soma(0.5).cai = 0.0075
        LP.axon(0.5).v = LP.axon(0.5).leak.e
        LP.h.cai0_ca_ion = 0.0075


    fihType = 0
    fih = [LP.h.FInitializeHandler(fihType,finitFxn)]

    
    if caseStr == 'reboundInhib_10':
        rebound_params = {'initDur' : 0,
            'stepDur' : 10000,
            'finalDur' : 10000,
            'initVal' : 0,
            'stepVal': -5}
        iElect = LP.h.IClamp(LP.soma(0.5))
        iElect.delay = 0
        iElect.dur = 1e9
        
        stepTime,stepWfm = wfmGen.stepRamp(rebound_params['initDur'], rebound_params['stepDur'], rebound_params['finalDur'], rebound_params['initVal'], rebound_params['stepVal'])

        stepTimeHoc = LP.h.Vector(stepTime)
        stepWfmHoc = LP.h.Vector(stepWfm)
        
        
        
        stepWfmHoc.play(iElect._ref_amp,stepTimeHoc,True)
        
        LP.h.tstop = stepTimeHoc[-1]

        try:
            LP.h.cvode_active(cvodeBool)
            LP.h.run()
        except:
            LP.h.cvode_active(0)
            LP.h.run()
        v = np.array(LP_validation.voltageHoc['v_LP.soma'])
        t = np.array(LP_validation.timeHoc)
        
        
        burstTimeThreshold = rebound_params['finalDur']  # Used for burst detection
        burstProminenceThreshold = 0.1
        burstVoltageThreshold = -60

        initBool  = rebound_params['initDur']+rebound_params['stepDur'] < t 
        finalBool = rebound_params['initDur']+rebound_params['stepDur'] + rebound_params['finalDur']  > t
         
            
        idxOfInt = initBool & finalBool

        burstAnalysisOutput = burstAnalysis(t = t[idxOfInt], v = v[idxOfInt], 
            burstTimeThreshold = burstTimeThreshold, 
            burstVoltageThreshold=burstVoltageThreshold,
            burstProminenceThreshold = burstProminenceThreshold,
            plottingBoolean=False)
        
        
        
        fVal = np.mean(1000/(np.diff(np.array((burstAnalysisOutput['spikesPerBurstTimes'])).flatten())))
        spikeTimes = np.array((burstAnalysisOutput['spikesPerBurstTimes'])).flatten()
        nBins = int(rebound_params['stepDur'] / 200)
        
        
        
        offsetVals = (spikeTimes-t[idxOfInt][0])/1000

        hist, times = np.histogram(offsetVals,nBins)
        ydata = np.cumsum(hist)
        xdata = times[:-1]
        if len(offsetVals) < 5:
            popt = [np.nan]*3
            latencyVal = np.nan
        else:
            p0 = [max(ydata), np.median(xdata),1] 
            try:
                popt, pcov = curve_fit(ac_sigmoid, xdata, ydata,p0, method='dogbox')
            except:
                popt = [np.nan]*3

            try:
                latencyVal = ((spikeTimes - t[idxOfInt][0])[0])/1000
            except:
                latencyVal = np.nan
        reboundSigFit = {'popt':popt,'latencyVal':latencyVal,'xdata':xdata,'ydata':ydata}

        
    elif caseStr == 'fiCurve':

        FI_params = {'initDur' : 500,
        'stepDur' : 5000,
        'finalDur' : 500,
        'initVal' : 0,
        'stepValArray':np.arange(-10,5.5,0.5)}

        iElect = LP.h.IClamp(LP.soma(0.5))
        iElect.delay = 0
        iElect.dur = 1e9

        vList = []
        tList = []
        fList = []
        for stepIdx,stepVal in enumerate(FI_params['stepValArray']):
            stepTime,stepWfm = wfmGen.stepRamp(FI_params['initDur'], FI_params['stepDur'], FI_params['finalDur'], FI_params['initVal'], stepVal)
            
            stepTimeHoc = LP.h.Vector(stepTime)
            stepWfmHoc = LP.h.Vector(stepWfm)
            
            stepWfmHoc.play(iElect._ref_amp,stepTimeHoc,True)
            
            LP.h.tstop = stepTimeHoc[-1]
            try:
                try:
                    LP.h.cvode_active(cvodeBool)
                    LP.h.run()
                except:
                    LP.h.cvode_active(0)
                    LP.h.run()
                    

                vList.append(np.array(LP_validation.voltageHoc['v_LP.soma']))
                tList.append(np.array(LP_validation.timeHoc))    

                initBool = FI_params['initDur'] +(FI_params['stepDur']/2) < tList[stepIdx] 
                finalBool = FI_params['initDur']+FI_params['stepDur'] > tList[stepIdx]
                idxOfInt = initBool & finalBool
                
                burstAnalysisOutput = burstAnalysis(t = tList[stepIdx][idxOfInt], v = vList[stepIdx][idxOfInt], 
                    burstTimeThreshold = FI_params['stepDur'], 
                    burstVoltageThreshold=-45,
                    burstProminenceThreshold = 1,
                    plottingBoolean=False)
                try:
                    fVal = np.mean(1000/(np.diff(np.array((burstAnalysisOutput['spikesPerBurstTimes'])).flatten())))
                except:
                    fVal = 0
                
                if np.isnan(fVal) == True:
                    fVal = 0

            except:
                vList.append(np.array([]))
                tList.append(np.array([]))
                fVal = np.nan
            
            fList.append(fVal)
            if np.sum(fList)>0:
                try:
                    p0 = [max(fList), 0.5,1]
                    powerFitParams, powerFitCoVar = curve_fit(ac_powerFxn, FI_params['stepValArray'], fList,p0) 
                except:
                    powerFitParams = np.array([np.nan]*3)
            else:
                powerFitParams = np.array([np.nan]*3)

                

    

    if fullReturn == False:
        if 'rebound' in caseStr:
            return reboundSigFit
        elif caseStr == 'fiCurve':
            return {'fList':fList, 'FI_params':FI_params,'powerFitParams':powerFitParams}
    if fullReturn == True:
        if 'rebound' in caseStr:
            return {'popt':popt,'latencyVal':latencyVal,'xdata':xdata,'ydata':ydata,'t':t, 'v':v,'rebound_params':rebound_params}
        elif caseStr == 'fiCurve':
            return {'fList':fList, 'FI_params':FI_params,'tList':tList, 'vList':vList}

def singleRun(params,mechsList, caseStr):
    outputDict = modelRun(params = params, mechsList = mechsList, caseStr = caseStr, mechsVarsOfInt = {}, caseVars = None)
    return outputDict
