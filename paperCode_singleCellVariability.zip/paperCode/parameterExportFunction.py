# -*- coding: utf-8 -*-
"""
Created on Mon Sep 7th 14:26:19 2020
Last updated on Mon Sep 7th 14:26:19 2020
parameterExportFunction
@author: omar
"""

"""
Function that takes NEURON section (Cell.section) and exports it to a csv with name specified by fileNameStr.
"""

import pandas as pd

def parameterExportFunction(cell,section,fileNameStr):

    pSectionData = section.psection()

    sectionFieldsList = ['density_mechs',]
    #  'ions',
    #  'morphology',
    # 'nseg',
    # 'Ra',
    # 'cm',
    # 'regions',
    # 'species' ]
                    
    dfDict= {}

    for fieldStr in sectionFieldsList:
        dfDict[fieldStr] = pd.io.json.json_normalize(pSectionData[fieldStr])
        dfDict[fieldStr].index = ['Value']
        dfDict[fieldStr] = dfDict[fieldStr].T

    extendedDf = pd.DataFrame()

    for idx,key in enumerate(dfDict):
        extendedDf = extendedDf.append(dfDict[key])

    #recover hoc name
    paramList = list(extendedDf.index)

    hocNameList = []
    unitsList = []

    for idx, paramStr in enumerate(paramList):
        dotIndex = str.find(paramStr, '.')
        if dotIndex != -1:
            hocNameStr = paramStr[dotIndex+1:len(paramStr)] + '_' + paramStr[0:dotIndex]
        else:
            hocNameStr = paramStr
        hocNameList.append(hocNameStr)
        unitsList.append(cell.h.units(hocNameStr))

    hocNameUnitDf = pd.DataFrame([hocNameList,unitsList])
    hocNameUnitDf.columns = paramList
    hocNameUnitDf.index = ['hocName','Units']
    extendedDf = extendedDf.join(hocNameUnitDf.T)
    extendedDf.to_csv(fileNameStr)    