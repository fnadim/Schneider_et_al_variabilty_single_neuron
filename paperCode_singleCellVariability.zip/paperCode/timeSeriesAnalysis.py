#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb  3 04:28:44 2020
# TO-DO:
- Generalize routines of spiking and burst analysis -- Mar 30 2020
- Collate peak analysis args in a dict, allow args to have vals for consideration or empty for exclusion -- Mar 30 2020

@author: omar
"""

import numpy as np
from scipy.signal import find_peaks

def burstAnalysis(t,v,burstTimeThreshold, burstVoltageThreshold,burstProminenceThreshold,
plottingBoolean=False, phaseBoolean = False, cycleStartTime=None, cycleEndTime= None,
minSpikesPerBurst = 0, minTotalSpikes = 3):
    # Peak detection    
    
#    burstTimeThreshold = 500 # in units of t (here ms)
#    burstVoltageThreshold = -35
    verticalDistThreshold = None
    distanceThreshold = None
    #prominenceThreshold = 5
    widthThreshold = None
    # Spike Detection
    spikeIdx, spikeProps = find_peaks(v, height = burstVoltageThreshold, threshold = verticalDistThreshold,
                                     distance = distanceThreshold, prominence = burstProminenceThreshold,
                                     width = widthThreshold)
    spikeProminences = spikeProps['prominences']
    # Non-spike peak detection

# Add condition such that a comparison is made btw spikes and oscillations, in some threshold
    # Within, let's say < 3 peaks, calculate. ohterwise, set everything to zero? or just take the difference and set that as an attribute?

    peakIdx, peakProps = find_peaks(v)    
    
    if len(peakIdx) > 0:    
        subPromPeaksRatio = len(spikeIdx)/len(peakIdx)  # Ideally, this should be close to 1. 
    else:
        subPromPeaksRatio = np.array(([0]))

    if np.size(spikeIdx) > minTotalSpikes: # the cutoff was at least 2 spikes, chaning to allow for greater dynamic range for the MI-T question -- April 26, 2021 - oi
        ## Calculating Interspike interval -- incldues the burst interval.
        ISI = np.diff(t[spikeIdx])
            
        burstLocsIdx = np.ravel(np.where(np.greater(ISI,burstTimeThreshold)))
        burstLocsIdx = burstLocsIdx.astype('int')
        
        burstLocs = ISI[burstLocsIdx]
        #%%
        burstStartIdx = []
        burstStartIdx = np.ravel(burstLocsIdx) #np.ravel(np.add(burstLocsIdx,1.0))
        burstStartIdx = np.concatenate((np.array([0]),np.array(np.add(burstStartIdx,1.0))))
        burstStartIdx = burstStartIdx.astype('int')
        
        #TEMP_firstBurstEnd = np.array([burstLocsIdx[0]-1.0])
        
        TEMP_lastBurstEnd = np.array([np.size(spikeIdx)-1]) # to account for 0 indexing
        #burstEndIdx = np.concatenate((TEMP_firstBurstEnd,burstLocsIdx,TEMP_lastBurstEnd))
        burstEndIdx = np.concatenate((burstLocsIdx,TEMP_lastBurstEnd))
        
        burstEndIdx = burstEndIdx.astype('int')
        #%% Burst Duration
        burstDurationIdx = spikeIdx[burstEndIdx] - spikeIdx[burstStartIdx]
        burstDurationTime = t[burstDurationIdx]
        #%% Calculate interbust mean voltage
        TEMP_IBI_startIdx = np.delete(burstEndIdx,-1)
        #TEMP_IBI_startIdx = np.concatenate((np.array([0]),TEMP_IBI_startIdx))
        
        TEMP_IBI_endIdx = np.delete(burstStartIdx,0)
        #TEMP_IBI_endIdx = np.concatenate((np.array([1]),TEMP_IBI_endIdx))
        
        IBI_startIdx = np.concatenate(([0],spikeIdx[TEMP_IBI_startIdx]))
        IBI_endIdx = np.concatenate(([spikeIdx[1]],spikeIdx[TEMP_IBI_endIdx]))
        
        IBIDurationIdx =  IBI_endIdx - IBI_startIdx
        IBIDurationTime = t[IBIDurationIdx]
        
        # meanIBIVoltage =np.nanmean(v[IBIDurationIdx])
        # minIBIVoltage = np.min(v[IBIDurationIdx])
        
        #%% Peaks voltage vals and mean vPeak, peakProm
        peakVoltages = v[spikeIdx]
        meanPeaksVoltage = np.nanmean(peakVoltages)
        meanSpikeProminences =np.nanmean(spikeProminences)
        
        meanPeakProminencePerBurst = np.array([])
        meanPeakVoltagePerBurst = np.array([])
        
        meadianPeakProminencePerBurst = np.array([])
        medianPeakVoltagePerBurst = np.array([]) 
        
        medianPeakVoltagePerBurst = np.array([]) 
        minIBIVoltage = np.array([]) 
        meanIBIVoltage = np.array([]) 
        
        
        spikesPerBurst = np.array([]) 
        
        spikeFreqOfBurst =  np.array([]) 
        
        # just to init 
        spikesPerBurstTimes = []
               
        meanBurstPlateuPerBurst = np.array([]) 
        medianBurstPlateuPerBurst = np.array([]) 
        
        meanMinIBIVoltage = np.array([]) 
        dutycyclePerBurst = np.array([]) 
    
        minIBIIdx = np.array([]) 

        burstStartTime = t[spikeIdx[burstStartIdx]]
        burstEndTime = t[spikeIdx[burstEndIdx]]
        
        
        for nBursts in range(np.size(burstEndIdx)):
            burstRangeIdx = range(burstStartIdx[nBursts],burstEndIdx[nBursts])
            if len(spikeIdx[burstRangeIdx]) > minSpikesPerBurst: # Checks to see if there are spikes in a burst.
                meanPeakProminencePerBurst = np.append(meanPeakProminencePerBurst, np.nanmean(spikeProminences[burstRangeIdx][1:-1]))
                meanPeakVoltagePerBurst = np.append(meanPeakVoltagePerBurst, np.nanmean(v[spikeIdx[burstRangeIdx]]))
                meadianPeakProminencePerBurst= np.append(meadianPeakProminencePerBurst, np.median(spikeProminences[burstRangeIdx]))
                medianPeakVoltagePerBurst = np.append(medianPeakVoltagePerBurst, np.median(v[spikeIdx[burstRangeIdx]]))
                
                IBIrangeIdx = range( IBI_startIdx[nBursts], IBI_endIdx[nBursts] )
                
                meanIBIVoltage = np.append(meanIBIVoltage,np.nanmean( v[ IBIrangeIdx ]  ) )
                minIBIVoltage = np.append(minIBIVoltage,np.min( v[ IBIrangeIdx ]  ) )

                minIBI_idxVal = np.where( v[ IBIrangeIdx ] == minIBIVoltage[-1])
                minIBI_idxVal = minIBI_idxVal + IBI_startIdx[nBursts]
                minIBIIdx = np.append(minIBIIdx, minIBI_idxVal)

                meanMinIBIVoltage = np.append(meanMinIBIVoltage,np.nanmean(minIBIVoltage))
                #%% Determine bursting plateu
                meanBurstPlateuPerBurst = np.append(meanBurstPlateuPerBurst,meanPeakVoltagePerBurst[nBursts] - meanPeakProminencePerBurst[nBursts])
                medianBurstPlateuPerBurst = np.append(medianBurstPlateuPerBurst,medianPeakVoltagePerBurst[nBursts] - meadianPeakProminencePerBurst[nBursts] )               

                dutycyclePerBurst = np.append(dutycyclePerBurst,burstDurationTime[nBursts] / (np.add(burstDurationTime[nBursts],IBIDurationTime[nBursts])))
    
                spikesPerBurstIdx = spikeIdx[range(burstStartIdx[nBursts],burstEndIdx[nBursts]+1)]
                
                spikesPerBurstTimes.append([t[spikesPerBurstIdx]])
                
                
                spikesPerBurst   = np.append(spikesPerBurst,np.add(burstEndIdx[nBursts] - burstStartIdx[nBursts],1)) # to account for zero indexing 
                spikeFreqOfBurst = np.append(spikeFreqOfBurst,spikesPerBurst[nBursts] / burstDurationTime[nBursts]) # this will be in units of time given (ie 1/msec or 1/sec, ...)      
 
            else:
                meanPeakProminencePerBurst = np.append(meanPeakProminencePerBurst, 0)
                meanPeakVoltagePerBurst = np.append(meanPeakVoltagePerBurst,0)
                meadianPeakProminencePerBurst= np.append(meadianPeakProminencePerBurst, 0)
                medianPeakVoltagePerBurst = np.append(medianPeakVoltagePerBurst, 0)
                                
                meanIBIVoltage = np.append(meanIBIVoltage, 0 )
                minIBIVoltage  = np.append(minIBIVoltage,  0 )

                minIBIIdx  = np.append(minIBIVoltage,  0 )
    
                meanMinIBIVoltage = np.append(meanMinIBIVoltage,0)
                #%% Determine bursting plateu
                meanBurstPlateuPerBurst = np.append(meanBurstPlateuPerBurst,0)
                medianBurstPlateuPerBurst = np.append(medianBurstPlateuPerBurst,0)               

                dutycyclePerBurst = np.append(dutycyclePerBurst,0)
                
                spikesPerBurstTimes.append([0])
                
                spikesPerBurst   = np.append(spikesPerBurst,  0) # to account for zero indexing 
                spikeFreqOfBurst = np.append(spikeFreqOfBurst,0) # this will be in units of time given (ie 1/msec or 1/sec, ...)      


        
        #%% Phase of Burst Onset
        """
        Where cycleStartTime is a list/array, where the elements are the start times of the cycle.
        TO-DO: make this routine more robust+modular.
        """
        # cycleStartTime = tVect[cycleOfInterest*5 - 3]
        # cycleEndTime = tVect[cycleOfInterest*5 + 2]
        phaseOfBurstOnset = np.array([])
        phaseOfBurstEnd = np.array([])

        if phaseBoolean == True:
            for cycleIdx, cycleStartVal in enumerate(cycleStartTime):
                cycleLength = cycleEndTime[cycleIdx] - cycleStartTime[cycleIdx]

                firstSpikeTimeVal = burstStartTime[(burstStartTime>cycleStartTime[cycleIdx]) & (burstStartTime<cycleEndTime[cycleIdx])]

                if firstSpikeTimeVal.size == 0:
                    phaseOfBurstOnset = np.append(phaseOfBurstOnset, 0)
                else:
                    phaseOfBurstOnset = np.append(phaseOfBurstOnset, 
                                                  (firstSpikeTimeVal - cycleStartTime[cycleIdx]) / (cycleLength)  )            
        
                lastSpikeTimeVal = burstEndTime[(burstEndTime>cycleStartTime[cycleIdx]) & (burstEndTime<cycleEndTime[cycleIdx])]

                if lastSpikeTimeVal.size == 0:
                    phaseOfBurstEnd = np.append(phaseOfBurstEnd, 0)
                else:
                    phaseOfBurstEnd = np.append(phaseOfBurstEnd, 
                                                (lastSpikeTimeVal - cycleStartTime[cycleIdx]) / (cycleLength)  )            
                        
        else:
            phaseOfBurstOnset = np.zeros_like(cycleStartTime)
            phaseOfBurstEnd = np.zeros_like(cycleEndTime)

        #%% Validation Plot
        if plottingBoolean == 1:
            import matplotlib.pyplot as plt
            maxVoltage = np.max(v)
            minVoltage = np.min(v)
            spanVoltage = maxVoltage - minVoltage
            hLineBurstDurationVoltage = (spanVoltage / 100) + maxVoltage
            hLineIBIVoltage =  minVoltage - 1
            
            plt.figure()
            plt.plot(t,v,color = 'black')
            plt.plot(t[spikeIdx[burstStartIdx]],v[spikeIdx[burstStartIdx]],'x',color='blue')
            plt.plot(t[spikeIdx[burstEndIdx]],v[spikeIdx[burstEndIdx]],'o',color='red')
            plt.hlines(meanMinIBIVoltage,0,t[-1],color= '#33FF33',linestyle='--') # plt.hlines(meanIBIVoltage,t[0],t[-1]) # This plots the base-line voltage of the oscillatoin
            
            for nBursts in range(np.size(burstEndIdx)):
                plt.hlines(hLineBurstDurationVoltage, t[spikeIdx[burstStartIdx[nBursts]]], t[spikeIdx[burstEndIdx[nBursts]]],color='blue')
                plt.hlines(hLineIBIVoltage, t[IBI_startIdx[nBursts]], t[IBI_endIdx[nBursts]],color='red')
                plt.hlines(medianBurstPlateuPerBurst[nBursts], t[spikeIdx[burstStartIdx[nBursts]]], t[spikeIdx[burstEndIdx[nBursts]]],color='orange')
                plt.hlines(meanBurstPlateuPerBurst[nBursts], t[spikeIdx[burstStartIdx[nBursts]]], t[spikeIdx[burstEndIdx[nBursts]]],color='magenta')
            for nSpikes in range(np.size(spikeIdx)):
                plt.vlines(t[spikeIdx[nSpikes]], v[spikeIdx[nSpikes]] - spikeProminences[nSpikes], v[spikeIdx[nSpikes]],color='green')

    else:
        spikesPerBurst = np.array(([0]))
        spikeFreqOfBurst = np.array(([0]))
        meanPeakProminencePerBurst = np.array(([0]))
        meanPeakVoltagePerBurst = np.array(([0]))
        medianBurstPlateuPerBurst = np.array(([0]))
        minIBIVoltage = np.array(([0]))
        dutycyclePerBurst = np.array(([0]))
        burstDurationTime =  np.array(([0]))
        spikesPerBurstTimes = np.array(([0]))
        burstStartIdx = np.array(([0]))
        burstEndIdx = np.array(([0]))
        burstStartTime = np.array(([0])) #([0])
        burstEndTime = np.array(([0])) # ([0])
        phaseOfBurstOnset = np.array(([0]))
        phaseOfBurstEnd = np.array(([0]))
        spikeIdx = np.array(([0]))
        minIBIIdx = np.array([0]) 
        
    burstAnalysisOutput = {"spikesPerBurst" :  (spikesPerBurst), 
                           "spikesPerBurstTimes": (spikesPerBurstTimes),
                           "spikeFreqOfBurst" :  (spikeFreqOfBurst),
                           "meanPeakProminencePerBurst":(meanPeakProminencePerBurst),
                           "meanPeakVoltagePerBurst" :  (meanPeakVoltagePerBurst), 
                           "medianBurstPlateuPerBurst" : (medianBurstPlateuPerBurst), 
                           "minIBIVoltage" :  (minIBIVoltage),
                           "dutycyclePerBurst" :  (dutycyclePerBurst),
                           "burstDurationTime" :  (burstDurationTime),
                           "burstStartIdx" : (burstStartIdx),
                           "burstEndIdx" : (burstEndIdx),
                           "burstStartTime": (burstStartTime),
                           "burstEndTime": (burstEndTime),                          
                           "phaseOfBurstOnset": (phaseOfBurstOnset),
                           "phaseOfBurstEnd": (phaseOfBurstEnd),
                           "subPromPeaksRatio" : (subPromPeaksRatio),
                           "spikeIdx":(spikeIdx),
                           "minIBIIdx":(minIBIIdx),
                           }
        
    return burstAnalysisOutput