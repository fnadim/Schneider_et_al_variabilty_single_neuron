#%% Units Comment
# =============================================================================
# g_bar = 'uS/mm2'
# i = 'mA/cm2'
# cm = 'uF/cm2'
# area = 'um2'
# Ra ='ohm-cm'
# v = 'mV'
# um2 to mm2 = 1e-6
# um2 to cm2 = 1e-8
# um to cm = 1e-4
# cm to um = 1e4
# =============================================================================
#%% Make Sections
class makeCell:
    def __init__(self,cellName, h = None):
        if h is None:
            from neuron import h, gui
        self.h = h
        self.soma = h.Section(name = 'soma', cell=cellName)
        self.axon = h.Section(name = 'axon', cell=cellName)

        self.soma.nseg = 1
        self.axon.nseg = 1

        self.soma.L = 200    # um, length
        self.soma.diam = 200  # um, diameter

        self.axon.L =    200  # um
        self.axon.diam=  200  # um

        self.somaArea_mm2 = self.soma(0.5).area() / 1e6
        self.somaArea_cm2 = self.soma(0.5).area() / 1e8

        self.axonArea_mm2 = self.axon(0.5).area() / 1e6
        self.axonArea_cm2 = self.axon(0.5).area() / 1e8


        self.somaSection = h.SectionList()
        self.somaSection.append(self.soma)
        self.axonSection = h.SectionList()
        self.axonSection.append(self.axon)
        
        self.axon.connect(self.soma(1))

        for seg in self.axonSection:
            seg.cm =  (0.000001) / self.axonArea_cm2
            seg.Ra = 1e5
            
            seg.insert('leak')
            seg.gbar_leak =  0.0001 / self.axonArea_mm2
            seg.e_leak = -55
            
            seg.insert('na')
            seg.gbar_na =  1.875 / self.axonArea_mm2
            seg.e_na = 70
            seg.vhalfm_na = -18
            seg.vslopem_na = -12.25
            seg.vhalfh_na = -28
            seg.vslopeh_na = 7.7
            seg.taum_na = 1
            seg.tauh_na = 2.5

            seg.insert('k') 
            seg.gbar_k = 0.5625 / self.axonArea_mm2
            seg.e_k = -80
            seg.vhalfm_k = -23
            seg.vslopem_k = -5
            seg.betaTaum_k = 7

        for seg in self.somaSection:
            seg.cm = (0.00125) / self.somaArea_cm2
            seg.Ra = 2e5
            
            seg.insert('leak')
            seg.gbar_leak = 0.08 / self.somaArea_mm2
            seg.e_leak = -50 
            
            seg.insert('a')
            seg.gbar_a = 5.18 / self.somaArea_mm2
            seg.e_a = -80
            seg.taum_a = 2
            seg.vhalfm_a = -10
            seg.vslopem_a = -20
            seg.tauh_a = 50
            seg.vhalfh_a = -60
            seg.vslopeh_a = 75
            
            
            seg.insert('hliu')
            seg.gbar_hliu = 0.015 / self.somaArea_mm2
            seg.taum_vhalf_hliu = -60
            seg.taum_vslope_hliu = -4
            seg.taum_alpha_hliu = 2500
            seg.taum_beta_hliu = 1500
            seg.vhalfm_hliu = -70
            seg.vslopem_hliu = 3
           
            seg.insert('kca')    
            seg.gbar_kca = 3 / self.somaArea_mm2 
            seg.e_kca = -80 
            seg.caiFactm_kca = 1.43e-3 
            seg.caiFactExpm_kca = -5 
            seg.vslopem_kca = -8 
            seg.vhalfm_kca = -5.5
            seg.alphaTaum_kca  = 499  
            seg.betaTaum_kca  = 5-499 
            seg.vhalfTaum_kca  = -51.9
            seg.vhalfTaumShift_kca  = 2.7
            seg.caiFactTaum_kca   = 1e-3 
            seg.deltaTaum_kca  = -0.1  
            seg.tauh_kca  = 25 
            seg.caiFacth_kca = 10e-3
            seg.caiFactExph_kca = 1.25 

            seg.insert('ca')    
            seg.Pbar_ca = 0.23625 
            seg.vhalfm_ca  = -45 
            seg.vslopem_ca = -15
            seg.alphaTaum_ca = 100
            seg.betaTaum_ca =  2500
            seg.vhalftaum_ca = -40 
            seg.vslopetaum_ca = -20
            seg.alphaTauh_ca = 500
            seg.betaTauh_ca =  2500
            seg.vhalftauh_ca = -70
            seg.vslopetauh_ca = -5
            seg.hinf_cai_ca = 5e-4 


            seg.insert('caint')
            seg.Pbar_caint =  0.0467        # nm/ms
            seg.Pbar1_caint= 1.1675   # um^3/s
            seg.vol1_caint = 6.49    # um^3
            seg.tau_caint = 25

            seg.insert('mi')
            seg.gbar_mi = 0  
            seg.e_mi = -10   
            seg.vhalfm_mi = -48
            seg.vslopem_mi = -5
            seg.taum_mi = 5


        h.celsius = 10   # degC
        h.cai0_ca_ion= 2e-5 # mM
        h.cao0_ca_ion= 13  # mM


        self.name = cellName
