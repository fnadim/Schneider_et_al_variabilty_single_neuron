import mechanismSelector

class masterValidation:
    def __init__(self,nrnModule,h = None):
        if h == None:
            from neuron import h
        self.h = h   
        self.nrnModule = nrnModule
        self.nrnModuleName = str(nrnModule)
        self.voltageHoc = {}
        self.timeHoc = []
        self.allSectionMechs = {}
        self.sectionMechs = {}
        for sec in nrnModule.h.allsec():
            self.allSectionMechs.update({sec.psection()['name'] : sec.psection()})

            
    def voltageHocGen(self):
        for sec in self.nrnModule.h.allsec():
            hocName = 'v_'+ str(sec)
            self.voltageHoc.update({ hocName : self.h.Vector()})
            self.voltageHoc[hocName].record(getattr(sec(0.5),'_ref_v'))
        
    def timeHocGen(self):
        self.timeHoc = self.h.Vector()
        self.timeHoc.record(self.nrnModule.h._ref_t)
        
    def mechsOfModule(self,mechsOfInterest,varsOfInterest):
        for sec in self.nrnModule.h.allsec():
            secName = str(sec)
            psectionVals = sec.psection()
            mechSelect = mechanismSelector.VarsRecorder(sec(0.5),psectionVals['density_mechs'],self.h)
            self.sectionMechs.update({secName : mechSelect})
            self.sectionMechs[secName].selectMechs(mechsOfInterest,varsOfInterest)
            self.sectionMechs[secName].hocVecGen()
            
    
    def vClampValidation(self,tVect,voltageVect,clampSection):
        for sec in clampSection:
            voltageVect.play(sec(0.5)._ref_v, tVect, True)
        self.h.v_init = voltageVect[0] 
        self.h.tstop = tVect[-1]
        self.h.run()
    
    
    def dynClampValidation(self,tVect,gVect,clampSection):
        for sec in clampSection:
            gVect.play(sec(0.5)._ref_gbar_dclamp, tVect, True)
        self.h.tstop = tVect[-1]
        self.h.run()

    def setParams(self,mechsDict,cellsDict):
        for cellDictKey in mechsDict:
            cellOfInt = cellsDict[cellDictKey]
            cellDict = mechsDict[cellDictKey]
            for segmentNames in cellDict:
                segmentOfInt = getattr(cellOfInt,segmentNames)
                if segmentOfInt != None:
                    for mechName in cellDict[segmentNames]:
                        mechOfInt = getattr(segmentOfInt(0.5),mechName)
                        for paramName in cellDict[segmentNames][mechName]:
                            paramVal = cellDict[segmentNames][mechName][paramName]
                            setattr(mechOfInt,paramName, paramVal)
