import matplotlib.pyplot as plt
import numpy as np

class VarsRecorder:
    def __init__(self,segment,mechsDict,h):
        self.segment = segment
        self.segName = str(segment)
        self.mechsDict = mechsDict
        self.mechs = []
        self.refField = []
        self.hocNames = []
        self.hocDict = {}
        self.h = h
        for mechs in mechsDict:
            self.mechs.append(str(mechs))
        
    def selectMechs(self,mechsOfInterest,varsOfInterest):
        for mechs in self.mechs: # here mechs are the density mechs (ex. a, na, k, h, ... )
            if mechs in mechsOfInterest:
                for mechParams in self.mechsDict[mechs]:
                    if mechParams in varsOfInterest:
                        self.refField.append('_ref_'+str(mechParams)+'_'+str(mechs))
                        self.hocNames.append(str(mechs)+'_'+str(mechParams)+'_')

    def hocVecGen(self):
        for idxName, nameVals in enumerate(self.hocNames):
            self.hocDict.update({nameVals : self.h.Vector()})
            self.hocDict[nameVals].record(getattr(self.segment,self.refField[idxName]))

    def plotHoc(self,xVals,xLabel):
        plt.figure(figsize = [25,5])
        for idxNames,hocNames in enumerate(self.hocDict): 
            plt.subplot(1,len(self.hocNames),(idxNames+1))
            plt.plot(xVals, self.hocDict[hocNames])
            plt.xlabel(str(xLabel))
            plt.title(self.hocNames[idxNames])
            plt.tight_layout()
