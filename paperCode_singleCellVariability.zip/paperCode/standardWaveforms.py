# -*- coding: utf-8 -*-
"""
Created on Tue Mar 17 00:47:09 2020
Waveform Generator
Generates times and x values for commonly used waveforms like triangle ramps, steps, ramp and hold

@author: omar
"""
import matplotlib.pyplot as plt
import numpy as np

def stepRamp(initDur,stepDur,finalDur,initVal,stepVal):
    """Returns time and x vals that look like a stepRamp 
    
    Args: 
        initDur (num): duration for the initial span
        stepDur (num): duration for the step span
        finalDur (num): duration after step to end
        initVal (num): value that will be stepped from to stepVal
        stepVal (num): value that will be stepped to from initVal
    """
    stepTime = initDur + stepDur
    finalTime = stepTime + finalDur
    tVals = [0,initDur-1,initDur,stepTime-1,stepTime,finalTime]
    xVals = [initVal,initVal,stepVal,stepVal,initVal,initVal]
    
    return tVals,xVals

def triangleRamp(rampSpeed,initVal,finalVal):
    """Returns time and x vals that look like a triangleRamp 
    
    Args: 
        rampSpeed (num): how quickly the ramp should go from initVal
        initVal (num): value that the ramp starts at
        finalVal (num): value that the ramp goes to
    """
    xSpan = abs(finalVal - initVal)
    rampTime = xSpan /  rampSpeed
    tVals = [0,       rampTime*0.5, rampTime*1, rampTime*1.5, rampTime*2]
    xVals = [initVal, initVal,      finalVal,   initVal,      initVal]
    
    return tVals, xVals


def rampHold(rampSpeed,initVal,finalVal):
    """Returns time and x vals that look like a ramp that holds value between up and down ramp
    
    Args: 
        rampSpeed (num): how quickly the ramp should go from initVal
        initVal (num): value that the ramp starts at
        finalVal (num): value that the ramp goes to
    """
    xSpan = abs(finalVal - initVal)
    rampTime = xSpan /  rampSpeed
    tVals = [0, rampTime*0.5, rampTime*1.5, rampTime*2.5, rampTime*3.5,rampTime*4]
    xVals = [initVal, initVal, finalVal, finalVal, initVal, initVal]
    
    return tVals, xVals


def waveformGenerator(tVals,xVals,timeDelay,nCycles,plotBoolean):
        tVals = np.array(tVals)
        xVals = np.array(xVals)
        waveformValPoints = xVals
        waveformTimePoints = tVals + timeDelay
        if np.size(tVals) == np.size(xVals):
            for n in range(0,nCycles-1):
                waveformValPoints = np.append(waveformValPoints,xVals)
                waveformTimePoints = np.append(waveformTimePoints,tVals+waveformTimePoints[-1])
    
            if plotBoolean == 1:
                plt.figure(1)
                plt.plot(tVals,xVals)
                plt.title('Single Cycle')
                plt.xlabel('Time')
                plt.ylabel('Value')
                
                plt.figure(2)
                plt.plot(waveformTimePoints,waveformValPoints)
                plt.title('All Cycles')
                plt.xlabel('Time')
                plt.ylabel('Values')
        else:
            print('Error: tVals and xVals must be the same size')
        return waveformTimePoints,waveformValPoints